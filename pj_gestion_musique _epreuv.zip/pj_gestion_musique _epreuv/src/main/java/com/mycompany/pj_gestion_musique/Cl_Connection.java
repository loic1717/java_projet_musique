/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pj_gestion_musique;

/**
 *
 * @author COMPAORÉ Loïc
 */
public class Cl_Connection {
    //connection a la base de données
    public static String url = "//falbala.futaie.org:3306/compaorez";
    public static String login ="compaorez";
    public static String password ="eiH3doo9heet";
}
